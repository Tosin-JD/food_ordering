from django.contrib import admin
from .models import (Event, WhyUs,
                   WelcomeNote,
                   AnimatedIntro)


# Register your models here.
admin.site.register(Event)
admin.site.register(WhyUs)
admin.site.register(WelcomeNote)
admin.site.register(AnimatedIntro)

