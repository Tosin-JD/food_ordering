from django.shortcuts import render
from .models import Event
from django.views import generic


# Create your views here.
class EventList(generic.ListView):
    model = Event
    template_name = 'events/event_list.html'
    
