from django.db import models

# Create your models here.


class Event(models.Model):
    name = models.CharField(max_length=30)
    price = models.FloatField()
    intro = models.TextField(verbose_name='Introduction')
    reason_one = models.TextField()
    reason_two = models.TextField()
    reason_three = models.TextField()
    welcome_note = models.TextField()
    photo = models.ImageField(upload_to='events')
    
    def __str__(self):
        return self.name
    

class WhyUs(models.Model):
    title = models.CharField(max_length=30)
    reason = models.TextField()
    
    def __str__(self):
        return self.title
        
    class Meta:
        verbose_name_plural = 'Why Us'


class AnimatedIntro(models.Model):
    one_word_title = models.CharField(max_length=12)
    rem_title = models.CharField(max_length=38)
    note = models.TextField()
    slide = models.ImageField(upload_to='slides')


class WelcomeNote(models.Model):
    half_title = models.CharField(max_length=30)
    rem_title = models.CharField(max_length=30, verbose_name='Remaining Title')
    first_para = models.TextField(verbose_name='First Paragraph')
    sec_para = models.TextField(verbose_name='Second Paragraph')
    first_bul = models.TextField(verbose_name='First Bullet')
    sec_bul = models.TextField(verbose_name='Second Bullet')
    third_bul = models.TextField(verbose_name='Third Bullet')
    conclusion = models.TextField()
  
    
    