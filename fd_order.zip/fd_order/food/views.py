from django.shortcuts import render
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, get_object_or_404, redirect                      
from django.views import generic                   
from django.utils import timezone                       
from .models import (
    Category,
    Item,
    Order,
    OrderItem,
    Photos
)
from events.models import (Event, WelcomeNote,
                           WhyUs, AnimatedIntro)
from contact.models import Testimonial
from accounts.models import Chef


# Create your views here.
class HomeView(generic.ListView):
    model = Item
    template_name = 'index.html'
    
    def get_context_data(self, **kwargs):
        context = super(HomeView, self).get_context_data(**kwargs)
        context['item_list'] = Item.objects.all()
        context['event_list'] = Event.objects.all()
        context['category_list'] = Category.objects.all()
        context['whyus_list'] = WhyUs.objects.all()
        context['intro_list'] = AnimatedIntro.objects.all()
        context['welcome_list'] = WelcomeNote.objects.all()
        context['photos_list'] = Photos.objects.all()
        context['chef_list'] = Chef.objects.all()
        context['testimony_list'] = Testimonial.objects.filter(status=1)
        # And so on for more models
        return context


class SearchResultsView(generic.ListView):
    model = Item
    template_name = 'search_results.html'

    def get_queryset(self): # new
        query = self.request.GET.get('q')
        object_list = Item.objects.filter(
            Q(name__icontains=query) | Q(state__icontains=query)
        )
        return object_list

    
    
class CategoryView(generic.ListView):
    model = Category
    template_name = 'food/category_list.html'
    

class CategoryDetail(generic.DetailView):
    model = Category
    template_name = 'food/category_detail.html'


class CartDetail(generic.DetailView):
    model = Item
    template_name = "food/food_list.html"


class OrderView(generic.DetailView, LoginRequiredMixin):
    model = Order
    template_name = "food/order_detail.html"


class OrderList(generic.ListView, LoginRequiredMixin):
    template_name = "food/order_list.html"
    
    def get_queryset(self):
        return Order.objects.filter(user=self.request.user)


class CartList(generic.ListView, LoginRequiredMixin):
    model = OrderItem
    template_name = "food/cart_list.html"
    
    def get_queryset(self):
        return OrderItem.objects.filter(user=self.request.user)

class EditCart(generic.UpdateView):
    model = OrderItem
    template_name = 'food/cart_list.html'


class DeleteCart(generic.DeleteView):
    model = OrderItem
        

class ListOfFood(generic.ListView):
    model = Item
    template_name = 'food/food_list.html'

    
class FoodDetail(generic.DetailView):
    """view the food details and choose whether to add to cart or remove from cart"""
    model = Item
    template_name = "food/food_detail.html"
    
    
def add_to_cart(request, pk) :
    item = get_object_or_404(Item, pk = pk )
    order_item, created = OrderItem.objects.get_or_create(
        item=item,
        user = request.user,
        ordered = False
    )
    order_qs = Order.objects.filter(user=request.user, ordered= False)

    if order_qs.exists() :
        order = order_qs[0]
        
        if order.items.filter(item__pk = item.pk).exists() :
            order_item.quantity += 1
            order_item.save()
            messages.info(request, "Added quantity Item")
            return redirect("food:product", pk = pk)
        else:
            order.items.add(order_item)
            messages.info(request, "Item added to your cart")
            return redirect("food:product", pk = pk)
    else:
        ordered_date = timezone.now()
        order = Order.objects.create(user=request.user, ordered_date = ordered_date)
        order.items.add(order_item)
        messages.info(request, "Item added to your cart")
        return redirect("food:product", pk = pk)
 
   
def remove_from_cart(request, pk):
    item = get_object_or_404(Item, pk=pk )
    order_qs = Order.objects.filter(
        user=request.user, 
        ordered=False
    )
    if order_qs.exists():
        order = order_qs[0]
        if order.items.filter(item__pk=item.pk).exists():
            order_item = OrderItem.objects.filter(
                item=item,
                user=request.user,
                ordered=False
            )[0]
            order_item.delete()
            messages.info(request, "Item \""+order_item.item.item_name+"\" remove from your cart")
            return redirect("food:product")
        else:
            messages.info(request, "This Item not in your cart")
            return redirect("food:product", pk=pk)
    else:
        #add message doesnt have order
        messages.info(request, "You do not have an Order")
        return redirect("food:product", pk=pk)
        
        

class GalleryView(generic.ListView):
    model = Photos
    template_name = 'food/gallery.html'        










