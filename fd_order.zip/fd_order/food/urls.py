from django.urls import path
from .views import *


app_name = 'food'

urlpatterns = [
    path('', HomeView.as_view(), name='home'),
    path('food/', ListOfFood.as_view(), name='food_list'),
    path('food/<pk>/', FoodDetail.as_view(), name='food_detail'),
    path('add-to-cart/<pk>/', add_to_cart, name='add_to_cart'),
    path('remove-from-cart/<pk>/', remove_from_cart, name='remove_from_cart'),
    path('search/', SearchResultsView.as_view(), name='search'),
    path('cart/', CartList.as_view(), name='cart'),
    path('cart/<pk>/', CartList.as_view(), name='cart'),
    path('order/', OrderList.as_view(), name='order'),
    path('cart/<pk>/', OrderView.as_view(), name='order_list'),
    path('edit-cart/<int:pk>/', EditCart.as_view(), name='cart_edit'),
    path('delete-cart-item/<int:pk>/', DeleteCart.as_view(), name='cart_delete'),
]




