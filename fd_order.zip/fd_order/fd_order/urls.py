"""fd_order URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.urls import re_path
from django.views.static import serve
from food.views import HomeView, GalleryView
from search.views import SearchResultsView
from accounts.views import ThanksPage

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', HomeView.as_view(), name="home"),
    path('search-results/', SearchResultsView.as_view(), name="search_results"),
    path('thanks/', ThanksPage.as_view(), name='thanks'),
    path('food/', include('food.urls', namespace="food")),
    path('gallery/', GalleryView.as_view(), name='gallery'),
    path('events/', include('events.urls', namespace="events")),
    path('contact/', include('contact.urls', namespace="contact")),
    path('accounts/', include('accounts.urls', namespace='accounts')),
    path('accounts/', include('django.contrib.auth.urls')),
    
] 


# ... the rest of your URLconf goes here ...
if settings.DEBUG:
    urlpatterns += [
                 re_path(r'^media/(?P<path>.*)$', serve, {
                 'document_root': settings.MEDIA_ROOT,
            }),
        ]











