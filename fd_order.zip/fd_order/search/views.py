from django.shortcuts import render
from django.db.models import Q
from food.models import Item
from django.views.generic import ListView
# Create your views here.


class SearchResultsView(ListView):
    model = Item
    template_name = 'search/search_results.html'
    
    def get_queryset(self): # new
        query = self.request.GET.get('q')
        object_list = Item.objects.filter(
            Q(item_name__icontains=query) | Q(label__icontains=query)
        )
        return object_list
    
